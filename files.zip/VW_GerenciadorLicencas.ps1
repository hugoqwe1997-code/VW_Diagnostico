# ============================================================
#  VW INFORMATICA - GERENCIADOR DE LICENCAS
#  Use este script para criar, renovar e gerenciar chaves
# ============================================================

$ErrorActionPreference = "SilentlyContinue"

function Show-AdminMenu {
    Clear-Host
    Write-Host ""
    Write-Host "  +==============================================+" -ForegroundColor DarkCyan
    Write-Host "  |                                              |" -ForegroundColor DarkCyan
    Write-Host "  |  VW INFORMATICA - GERENCIADOR DE LICENCAS    |" -ForegroundColor Cyan
    Write-Host "  |                                              |" -ForegroundColor DarkCyan
    Write-Host "  +==============================================+" -ForegroundColor DarkCyan
    Write-Host "  |  [1] Gerar nova chave de licenca             |" -ForegroundColor White
    Write-Host "  |  [2] Renovar licenca (+ 30 dias)             |" -ForegroundColor White
    Write-Host "  |  [3] Desativar licenca                       |" -ForegroundColor White
    Write-Host "  |  [4] Listar todas as licencas                |" -ForegroundColor White
    Write-Host "  |  [5] Abrir licencas.json para editar         |" -ForegroundColor White
    Write-Host "  |  [6] Instrucoes de uso                       |" -ForegroundColor White
    Write-Host "  |  [0] Sair                                    |" -ForegroundColor DarkGray
    Write-Host "  +==============================================+" -ForegroundColor DarkCyan
    Write-Host ""
}

function Generate-Key {
    $part1 = "VW"
    $part2 = (Get-Random -Minimum 1000 -Maximum 9999).ToString()
    $chars = "ABCDEFGHJKLMNPQRSTUVWXYZ"
    $part3 = -join (1..4 | ForEach-Object { $chars[(Get-Random -Maximum $chars.Length)] })
    $part4 = (Get-Random -Minimum 1000 -Maximum 9999).ToString()
    return "$part1-$part2-$part3-$part4"
}

function New-License {
    Write-Host ""
    Write-Host "  === GERAR NOVA LICENCA ===" -ForegroundColor Cyan
    Write-Host ""
    $cliente = Read-Host "  Nome do cliente"
    $whatsapp = Read-Host "  WhatsApp (com DDD)"
    $pcs = Read-Host "  Quantos PCs pode usar (padrao: 1)"
    if (-not $pcs) { $pcs = "1" }
    
    $chave = Generate-Key
    $validade = (Get-Date).AddDays(30).ToString("yyyy-MM-dd")
    
    Write-Host ""
    Write-Host "  +----------------------------------------------+" -ForegroundColor Green
    Write-Host "  |  LICENCA GERADA COM SUCESSO!                 |" -ForegroundColor Green
    Write-Host "  +----------------------------------------------+" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Chave    : $chave" -ForegroundColor Yellow
    Write-Host "  Cliente  : $cliente" -ForegroundColor White
    Write-Host "  WhatsApp : $whatsapp" -ForegroundColor White
    Write-Host "  Validade : $validade (30 dias)" -ForegroundColor White
    Write-Host "  PCs      : $pcs" -ForegroundColor White
    Write-Host ""
    Write-Host "  Copie o trecho abaixo e COLE no licencas.json:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "    ""$chave"": {" -ForegroundColor Cyan
    Write-Host "      ""cliente"": ""$cliente""," -ForegroundColor Cyan
    Write-Host "      ""whatsapp"": ""$whatsapp""," -ForegroundColor Cyan
    Write-Host "      ""validade"": ""$validade""," -ForegroundColor Cyan
    Write-Host "      ""ativo"": true," -ForegroundColor Cyan
    Write-Host "      ""pcs"": $pcs," -ForegroundColor Cyan
    Write-Host "      ""plano"": ""mensal""" -ForegroundColor Cyan
    Write-Host "    }" -ForegroundColor Cyan
    Write-Host ""
    
    # Copiar chave para area de transferencia
    $chave | Set-Clipboard -ErrorAction SilentlyContinue
    Write-Host "  A chave foi copiada para a area de transferencia!" -ForegroundColor Green
    Write-Host ""
    Write-Host "  ENVIE PARA O CLIENTE:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  -----------------------------------------------" -ForegroundColor DarkGray
    Write-Host "  VW Informatica - Diagnostico e Reparo" -ForegroundColor White
    Write-Host ""
    Write-Host "  Sua chave de licenca: $chave" -ForegroundColor White
    Write-Host "  Valida ate: $validade" -ForegroundColor White
    Write-Host ""
    Write-Host "  Para usar, abra o PowerShell como Admin e cole:" -ForegroundColor White
    Write-Host "  Set-ExecutionPolicy Bypass -Scope Process -Force; iex ((New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/hugoqwe1997-code/VW_Diagnostico/main/VW_Diagnostico.ps1'))" -ForegroundColor White
    Write-Host ""
    Write-Host "  Duvidas: (74) 99937-8375" -ForegroundColor White
    Write-Host "  -----------------------------------------------" -ForegroundColor DarkGray
    Write-Host ""
}

function Renew-License {
    Write-Host ""
    Write-Host "  === RENOVAR LICENCA ===" -ForegroundColor Cyan
    Write-Host ""
    $chave = Read-Host "  Chave do cliente"
    $novaValidade = (Get-Date).AddDays(30).ToString("yyyy-MM-dd")
    
    Write-Host ""
    Write-Host "  Nova validade: $novaValidade (+30 dias)" -ForegroundColor Green
    Write-Host ""
    Write-Host "  No licencas.json, altere a linha 'validade' da chave:" -ForegroundColor Yellow
    Write-Host "    ""validade"": ""$novaValidade""" -ForegroundColor Cyan
    Write-Host ""
}

function Disable-License {
    Write-Host ""
    Write-Host "  === DESATIVAR LICENCA ===" -ForegroundColor Cyan
    Write-Host ""
    $chave = Read-Host "  Chave para desativar"
    Write-Host ""
    Write-Host "  No licencas.json, altere a linha 'ativo' da chave:" -ForegroundColor Yellow
    Write-Host "    ""ativo"": false" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  O cliente nao conseguira mais usar o sistema." -ForegroundColor Red
}

function List-Licenses {
    Write-Host ""
    Write-Host "  === LICENCAS CADASTRADAS ===" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  As licencas estao no arquivo licencas.json" -ForegroundColor DarkGray
    Write-Host "  que voce hospeda no GitHub Gist." -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  Abra o link do seu Gist para ver e editar:" -ForegroundColor Yellow
    Write-Host "  https://gist.github.com" -ForegroundColor Cyan
}

function Show-Instructions {
    Clear-Host
    Write-Host ""
    Write-Host "  +==============================================+" -ForegroundColor Cyan
    Write-Host "  |  COMO CONFIGURAR O SISTEMA DE LICENCAS       |" -ForegroundColor Cyan
    Write-Host "  +==============================================+" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  PASSO 1 - Criar Gist privado no GitHub" -ForegroundColor Yellow
    Write-Host "  ----------------------------------------" -ForegroundColor DarkGray
    Write-Host "  1. Acesse: https://gist.github.com" -ForegroundColor White
    Write-Host "  2. Faca login com sua conta (hugoqwe1997-code)" -ForegroundColor White
    Write-Host "  3. Nome do arquivo: licencas.json" -ForegroundColor White
    Write-Host "  4. Cole o conteudo do arquivo licencas.json" -ForegroundColor White
    Write-Host "  5. Marque 'Create secret gist' (PRIVADO)" -ForegroundColor Red
    Write-Host "  6. Clique 'Create secret gist'" -ForegroundColor White
    Write-Host ""
    Write-Host "  PASSO 2 - Copiar URL do arquivo RAW" -ForegroundColor Yellow
    Write-Host "  ----------------------------------------" -ForegroundColor DarkGray
    Write-Host "  1. No Gist criado, clique em 'Raw'" -ForegroundColor White
    Write-Host "  2. Copie a URL (ex: https://gist.githubusercontent.com/...)" -ForegroundColor White
    Write-Host "  3. IMPORTANTE: remova a parte '/raw/HASH/' e deixe so '/raw/'" -ForegroundColor Red
    Write-Host "     Assim sempre pega a versao mais recente" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  PASSO 3 - Colocar URL no script" -ForegroundColor Yellow
    Write-Host "  ----------------------------------------" -ForegroundColor DarkGray
    Write-Host "  1. No VW_Diagnostico.ps1, procure a linha:" -ForegroundColor White
    Write-Host '     $licUrl = "COLE_SUA_URL_DO_GIST_AQUI"' -ForegroundColor Cyan
    Write-Host "  2. Substitua pela URL do seu Gist Raw" -ForegroundColor White
    Write-Host "  3. Suba o script atualizado no GitHub" -ForegroundColor White
    Write-Host ""
    Write-Host "  PASSO 4 - Vender licencas" -ForegroundColor Yellow
    Write-Host "  ----------------------------------------" -ForegroundColor DarkGray
    Write-Host "  1. Use a opcao [1] deste gerenciador para gerar chaves" -ForegroundColor White
    Write-Host "  2. Envie a chave pro cliente apos pagamento" -ForegroundColor White
    Write-Host "  3. Cole a licenca no licencas.json do Gist" -ForegroundColor White
    Write-Host "  4. Todo mes: renove ou desative no Gist" -ForegroundColor White
    Write-Host ""
    Write-Host "  PRECO SUGERIDO:" -ForegroundColor Yellow
    Write-Host "  - Mensal: R$ 29,90 a R$ 49,90 por PC" -ForegroundColor Green
    Write-Host "  - Para assistencias tecnicas: R$ 79,90/mes" -ForegroundColor Green
    Write-Host "  - Acesso ilimitado (PCs): R$ 149,90/mes" -ForegroundColor Green
    Write-Host ""
}

# Loop principal
do {
    Show-AdminMenu
    $choice = Read-Host "  Escolha"
    
    switch ($choice) {
        "1" { New-License }
        "2" { Renew-License }
        "3" { Disable-License }
        "4" { List-Licenses }
        "5" { 
            $jsonPath = "$PSScriptRoot\licencas.json"
            if (Test-Path $jsonPath) { Start-Process notepad.exe $jsonPath }
            else { Write-Host "  Arquivo licencas.json nao encontrado na pasta atual" -ForegroundColor Red }
        }
        "6" { Show-Instructions }
        "0" { break }
    }
    
    if ($choice -ne "0") {
        Write-Host "`n  Pressione ENTER para voltar ao menu..." -ForegroundColor DarkGray
        Read-Host
    }
} while ($choice -ne "0")
