# ==============================================================
#  VW INFORMATICA - COMO CONFIGURAR O SISTEMA DE LICENCAS
# ==============================================================

# PASSO 1 - Criar Gist Privado no GitHub
# -----------------------------------------------
# 1. Acesse: https://gist.github.com
# 2. Faca login com hugoqwe1997-code
# 3. Em "Filename", coloque: licencas.json
# 4. Cole o conteudo do arquivo licencas.json
# 5. Clique "Create secret gist" (PRIVADO - so voce ve)
#
# PASSO 2 - Pegar a URL RAW
# -----------------------------------------------
# 1. No Gist criado, clique no botao "Raw"
# 2. A URL vai ser algo como:
#    https://gist.githubusercontent.com/hugoqwe1997-code/abc123.../raw/def456.../licencas.json
# 3. IMPORTANTE: Remova a parte do HASH do meio. Deixe assim:
#    https://gist.githubusercontent.com/hugoqwe1997-code/abc123.../raw/licencas.json
#    (Isso garante que sempre pega a versao mais recente)
#
# PASSO 3 - Colocar URL no Script
# -----------------------------------------------
# 1. Abra o VW_Diagnostico.ps1
# 2. Procure a linha (perto do inicio):
#    $licUrl = "COLE_SUA_URL_DO_GIST_AQUI"
# 3. Substitua pela sua URL RAW:
#    $licUrl = "https://gist.githubusercontent.com/hugoqwe1997-code/abc123.../raw/licencas.json"
# 4. Suba o script atualizado no GitHub
#
# PASSO 4 - Gerar Chaves para Clientes
# -----------------------------------------------
# 1. Execute VW_GerenciadorLicencas.ps1 no seu PC
# 2. Opcao [1] para gerar nova chave
# 3. Copie o trecho JSON gerado
# 4. Abra seu Gist e cole no licencas.json
# 5. Envie a chave pro cliente por WhatsApp
#
# PASSO 5 - Renovar Todo Mes
# -----------------------------------------------
# 1. Cliente paga -> voce abre o Gist
# 2. Muda a "validade" pra +30 dias
# 3. Salva. Pronto!
# Se nao pagar -> muda "ativo" para false
#
# COMO O CLIENTE USA
# -----------------------------------------------
# 1. Abre PowerShell como Admin
# 2. Cola o comando do GitHub
# 3. Digita a chave na primeira vez
# 4. A chave fica salva no PC (nao pede mais)
# 5. Todo mes o script verifica se a chave esta valida
# 6. Se vencer, mostra mensagem pedindo renovacao
#
# PRECOS SUGERIDOS
# -----------------------------------------------
# Uso pessoal (1 PC)     : R$ 29,90/mes
# Uso profissional (3 PC): R$ 49,90/mes
# Assistencia tecnica    : R$ 79,90/mes (PCs ilimitados)
# Plano anual            : 10x o valor mensal (2 meses gratis)
#
# ARQUIVOS DO SISTEMA
# -----------------------------------------------
# VW_Diagnostico.ps1       -> Script principal (sobe no GitHub publico)
# VW_Diagnostico.bat       -> Atalho para rodar (sobe no GitHub)
# Gerar_EXE.ps1            -> Gera o .exe (sobe no GitHub)
# README.md                -> Documentacao (sobe no GitHub)
# licencas.json            -> Chaves de licenca (sobe no Gist PRIVADO)
# VW_GerenciadorLicencas.ps1 -> Gerador de chaves (so pra voce, NAO sobe)
# INSTRUCOES.ps1           -> Este arquivo (so pra voce, NAO sobe)
